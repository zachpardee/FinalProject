Filename: README.txt
Authors: Kendall Willard, Zach Pardee
Date Created: March 25, 2019
Filename Description: This file contains the readme for the Game of Thrones
                      Fantasy League


********USER STORIES**********

1. As a user, I want to be able to draft a character

2. As a user, I want to be able to be able to view my current score.

3. As a user, I want to be able to see the characters I drafted.

4. As a user, I want to be able to see who drafted a specific character.

************How to run this game***********
